const app = require("./middlewares/app");
app.listen(3939, () => {
  console.log("Server is working");
});
