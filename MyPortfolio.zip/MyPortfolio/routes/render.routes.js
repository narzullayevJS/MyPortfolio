const express = require("express");
let router = express.Router();
const renderController = require("../controller/render.controller");
router.get("/", renderController.renderIndex);
router.get("/index", renderController.renderIndex);
router.get("/about", renderController.renderAbout);
router.get("/booking", renderController.renderBooking);
router.get("/contact", renderController.renderContact);
router.get("/service", renderController.renderService);

router.get("/package", renderController.renderPackage);
router.get("/team", renderController.renderTeam);
router.get("/testimonial", renderController.renderTetstimonial);
router.get("/404", renderController.renderError);

module.exports = router;
