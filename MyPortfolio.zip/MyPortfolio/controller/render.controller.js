let renderIndex = (req, res, next) => {
  res.render("index", {
    title: "Xususiy klinika",
  });
};
// Destination
let renderDestination = (req, res, next) => {
  res.render("destination", {
    title: "Imkoniyat",
  });
};
// Team
let renderTeam = (req, res, next) => {
  res.render("team", {
    title: "Xodimlar",
  });
};
// booking
let renderBooking = (req, res, next) => {
  res.render("booking", {
    title: "Rejalashtirish",
  });
};
// about
let renderAbout = (req, res, next) => {
  res.render("about", {
    title: "Biz haqimizda",
    image: "feature.jpg",
  });
};
// service
let renderService = (req, res, next) => {
  res.render("service", {
    title: "Xizmatlarimiz",
  });
};
// contact
let renderContact = (req, res, next) => {
  res.render("contact", {
    title: "Aloqalarimiz",
  });
};
// testimimonial
let renderTetstimonial = (req, res, next) => {
  res.render("testimonial", {
    title: "Sharh",
  });
};
// 404
let renderError = (req, res, next) => {
  res.render("404", {
    title: "Xatolik",
  });
};
// package
let renderPackage = (req, res, next) => {
  res.render("package", {
    title: "Xatolik",
  });
};

module.exports = {
  renderIndex,
  renderAbout,
  renderService,
  renderContact,
  renderBooking,
  renderTeam,
  renderPackage,
  renderTetstimonial,
  renderError,
};
